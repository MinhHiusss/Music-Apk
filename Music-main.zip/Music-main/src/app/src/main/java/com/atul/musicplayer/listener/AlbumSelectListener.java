package com.atul.musicplayer.listener;

import com.atul.musicplayer.model.Album;

public interface AlbumSelectListener {
    void selectedAlbum(Album album);
}

package com.atul.musicplayer.listener;

public interface MinuteSelectListener {
    void select(int minutes);
}

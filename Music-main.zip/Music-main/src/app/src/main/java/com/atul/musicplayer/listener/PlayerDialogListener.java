package com.atul.musicplayer.listener;

public interface PlayerDialogListener {
    void queueOptionSelect();

    void sleepTimerOptionSelect();
}
